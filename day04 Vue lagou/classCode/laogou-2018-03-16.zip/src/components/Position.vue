<template lang="html">
  <div class="m-position">
    <!-- <button @click="pushnew">加载</button> -->
    <signin :isshow="true"></signin>
    <main class="m-position-main">
      <mt-loadmore
      :top-method="loadTop"
      :bottom-method="loadBottom"
      :bottom-all-loaded="allLoaded"
      topDropText="放下了"
      @top-status-change="handleTopChange"
      ref="loadmore">
      <ul>
        <router-link :to="`/detail/${v._id}`" tag="li" :key="v._id" v-for="(v,i) in poslist">
          <img :src="`http://localhost:3000/uploads/${v.companyLogo}`">
          <div>
            <h2>{{v.companyName}}</h2>
            <p>
              <span>
                {{v.positionName}}
              </span>
              <span>{{v.positionSalary}}</span>
            </p>
            <p>{{v.createTime}}</p>
          </div>
        </router-link>
        <!-- <li v-for="(v,i) in count">{{v}}</li> -->
      </ul>
      <div slot="top" class="mint-loadmore-top">
        <div v-if="status=='pull'">aaa</div>
        <div v-if="status=='drop'">bbb</div>
        <div v-if="status=='loading'">ccc</div>
      </div>
    </mt-loadmore>
  </main>
</div>
</template>

<script>
import axios from 'axios'
import { Loadmore, Indicator } from 'mint-ui'
import Signin from './Sign.vue'
export default {
  data: () => {
    return {
      poslist: [],
      allLoaded: false,
      status: '',
      count: [1, 3, 3]
    }
  },

  methods: {
    loadTop() {
      setTimeout(() => {
        this.$refs.loadmore.onTopLoaded();
      }, 2000)
    },
    loadBottom() {
      setTimeout(() => {
        this.$refs.loadmore.onBottomLoaded();
      }, 2000)
      setTimeout(() => {
        this.allLoaded = true
      }, 8000)
    },
    handleTopChange(status) {
      switch (status) {
        case 'pull':
          this.status = 'pull'
          break;
        case 'drop':
          this.status = 'drop'
          break;
        case 'loading':
          this.status = 'loading'
          break;
        default:

      }
    },
    pushnew() {
      this.count.push(7)
      this.$nextTick(() => {
        console.log(this.$refs.myul.children.length);
      })
    }
  },

  created() {
  },

  mounted() {
    console.log(9);
    Indicator.open({
      text: '加载中...',
      spinnerType: 'fading-circle'
    })
    axios({
      url: '/api/position/m/list/',
      data: {
        start: 0,
        count: 10
      }
    })
      .then((result) => {
        this.poslist = result.data.data
        Indicator.close()
      })
  },

  components: {
    [Loadmore.name]: Loadmore,
    Signin
  }
}
</script>

<style lang="scss">
  @import '../styles/app.scss';
  .m-position {
    height: 100%;
    @include flexbox();
    @include flex-direction(column);
  }

  .m-position-main {
    overflow-y: scroll;
  }

  .container {
    .main {
      width: 100%;
      height: 100%;
      @include flexbox();
      @include flex-direction(column);
      nav {
        height: .44rem;
        .custom-info {
          height: 100%;
          @include flexbox();
          @include align-items();
          padding: 0 15px;
          span {
            @include flex();
          }
          a {
            width: .84rem;
            position: absolute;
            right: .15rem;
            top: 0;
            display: block;
            background-color: #f5f5f5;
            padding: 0 .2rem;
            height: .3rem;
            line-height: .3rem;
            margin-top: .06rem;
            color: $base-color;
            @include border-radius(.15rem);
          }
        }
        @include border(0 0 1px 0);
      }
      main {
        @include flex();
        width: 100%;
        overflow-y: scroll;
        ul {
          width: 100%;
          height: 100%;

          .head {
              text-align: center;
              height: 100px;
              line-height: 100px;
          }
          .head img {
              display: inline-block;
              transform: rotate(180deg);
              -webkit-transform: rotate(180deg);
              transition: transform 150ms;
              -webkit-transition: transform 150ms;
          }
          .up {
              transform: rotate(360deg) !important;
              -webkit-transform: rotate(360deg) !important;
          }
          .foot {
              text-align: center;
              height: 100px;
              line-height: 100px;
          }
          .foot img {
              display: inline-block;
              /*transform: rotate(0deg);*/
              /*-webkit-transform: rotate(0deg);*/
              transition: transform 150ms;
              -webkit-transition: transform 150ms;
          }
          .down {
              transform: rotate(180deg) !important;
              -webkit-transform: rotate(180deg) !important;
          }

          li {
            padding: .14rem;
            height: 1rem;
            @include flexbox();
            @include align-items();
            @include border(0 0 1px 0);



            > img {
              width: .6rem;
            }
            > div {
              padding-left: .06rem;
              @include flex();
              h2 {
                font-size: .18rem;
                margin-bottom: .04rem;
              }
              p {
                font-size: .14rem;
                height: .24rem;
                &:nth-child(2) {
                  @include flexbox();
                  span {
                    display: block;
                    height: 100%;
                    @include ellipsis();
                    &:first-child {
                      @include flex();
                    }
                    &:last-child {
                      width: .7rem;
                      color: $base-color;
                      font-size: .16rem;
                      text-align: right;
                      margin-bottom: .2rem;
                    }
                  }
                }
                &:last-child {
                  color: #888
                }
              }
            }
          }
        }
      }
    }
  }

</style>
