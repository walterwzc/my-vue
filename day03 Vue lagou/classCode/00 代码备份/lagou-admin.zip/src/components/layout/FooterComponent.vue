<template lang="html">
  <!-- Main Footer -->
  <footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
      好程序员5Node.js后台项目
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; 2018 <a href="#">HTML5 GP5</a>.</strong> All rights reserved.
  </footer>
</template>
