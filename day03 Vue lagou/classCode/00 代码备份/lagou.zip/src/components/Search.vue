<template>
  <div>
    <mt-button type="default">default</mt-button>
    <mt-button type="primary">primary</mt-button>
    <mt-button type="danger">danger</mt-button>
  </div>
</template>

<script>
  import Vue from 'vue'
  import { Button } from 'mint-ui'
  console.log(Button.name);
  export default {
    components: {
      [Button.name]: Button
    }
  }
</script>
